package com.product.report.enumeration;

public enum Status {
	Seldom, Often, Never, Weekly, Yearly, Daily, Monthly, Once
}
